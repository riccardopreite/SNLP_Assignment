# Riccardo Preite 4196104

N.B. The code could need a little amount of time to execute according to the lenght of the sentence that the program is generating

To execute generation of sentence in unigram, bigram and trigram:

python3 read_corpus.py